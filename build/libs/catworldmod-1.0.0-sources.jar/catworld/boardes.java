package catworld;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.minecraft.class_124;
import net.minecraft.class_1299;
import net.minecraft.class_2561;
import net.minecraft.class_2940;
import net.minecraft.class_3218;
import net.minecraft.class_8113;
import java.lang.reflect.Field;

public class boardes {

    private static class_2940<class_2561> TEXT_DATA_KEY = null;
    private static class_2940<Byte> BILLBOARD_DATA_KEY = null;
    private static class_2940<Integer> BACKGROUND_DATA_KEY = null;

    static {
        try {
            // 1. Достаем ключ ТЕКСТА
            Field textField;
            try {
                textField = class_8113.class_8123.class.getDeclaredField("TEXT");
            } catch (NoSuchFieldException e) {
                textField = class_8113.class_8123.class.getDeclaredField("field_42525");
            }
            textField.setAccessible(true);
            TEXT_DATA_KEY = (class_2940<class_2561>) textField.get(null);

            // 2. Достаем ключ БИЛЛБОРДА (он находится в родительском классе DisplayEntity)
            Field billboardField;
            try {
                billboardField = class_8113.class.getDeclaredField("BILLBOARD");
            } catch (NoSuchFieldException e) {
                billboardField = class_8113.class.getDeclaredField("field_42403");
            }
            billboardField.setAccessible(true);
            BILLBOARD_DATA_KEY = (class_2940<Byte>) billboardField.get(null);

            // 3. Достаем ключ ФОНА
            Field bgField;
            try {
                bgField = class_8113.class_8123.class.getDeclaredField("BACKGROUND");
            } catch (NoSuchFieldException e) {
                bgField = class_8113.class_8123.class.getDeclaredField("field_42523");
            }
            bgField.setAccessible(true);
            BACKGROUND_DATA_KEY = (class_2940<Integer>) bgField.get(null);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void reglas() {
        ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            class_3218 world = server.method_30002();
            if (world != null) {
                spawnLine(world, -32, 48.6, 343, "line1", "CatWorld RP", class_124.field_1065, true);
                spawnLine(world, -32, 48.9, 343, "line2", "Es un servidor bueno", class_124.field_1068, false);
            }
        });
    }

    private static void spawnLine(class_3218 world, double x, double y, double z,
                                   String tag, String text, class_124 color, boolean bold) {
        

        // Создаем новую сущность Text Display
        class_8113.class_8123 textDisplay = new class_8113.class_8123(class_1299.field_42457, world);
        
        // Задаем координаты
        textDisplay.method_5808(x, y, z, 0.0F, 0.0F);

        // Собираем чистый текст средствами Java (никакого JSON-парсинга строк в игре)
        class_2561 textComponent = class_2561.method_43470(text).method_27694(style -> style.method_10977(color).method_10982(bold));
        
        // Безопасно пихаем все данные в DataTracker через вскрытые ключи
        if (TEXT_DATA_KEY != null) {
            textDisplay.method_5841().method_12778(TEXT_DATA_KEY, textComponent);
        }
        if (BILLBOARD_DATA_KEY != null) {
            textDisplay.method_5841().method_12778(BILLBOARD_DATA_KEY, (byte) 2); // 2 — это режим CENTER
        }
        if (BACKGROUND_DATA_KEY != null) {
            textDisplay.method_5841().method_12778(BACKGROUND_DATA_KEY, 1073741824); // Цвет фона
        }

        // Добавляем командный тег
        textDisplay.method_5780(tag);

        // Спавним в мир
        world.method_8649(textDisplay);
    }
}
