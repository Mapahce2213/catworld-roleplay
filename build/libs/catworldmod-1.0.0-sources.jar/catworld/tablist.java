package catworld;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class tablist {

    private static class PlayerActivity {
        double x, y, z;
        float yaw, pitch;
        long lastActiveTime;
        boolean isAfk;

        PlayerActivity(class_3222 player) {
            this.x = player.method_23317();
            this.y = player.method_23318();
            this.z = player.method_23321();
            this.yaw = player.method_36454();
            this.pitch = player.method_36455();
            this.lastActiveTime = System.currentTimeMillis();
            this.isAfk = false;
        }

        boolean hasMoved(class_3222 player) {
            return this.x != player.method_23317() || this.y != player.method_23318() || this.z != player.method_23321() ||
                   this.yaw != player.method_36454() || this.pitch != player.method_36455();
        }

        void updatePosition(class_3222 player) {
            this.x = player.method_23317();
            this.y = player.method_23318();
            this.z = player.method_23321();
            this.yaw = player.method_36454();
            this.pitch = player.method_36455();
        }
    }
    
    private static final Map<UUID, PlayerActivity> playerActivityMap = new HashMap<>();
    private static final long AFK_TIMEOUT_MS = 60000; 

    public static void register() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.field_14140;
            playerActivityMap.put(player.method_5667(), new PlayerActivity(player));
            updatePlayerTab(server, player, false);
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            playerActivityMap.remove(handler.field_14140.method_5667());
        });

        ServerTickEvents.START_SERVER_TICK.register(server -> {
            if (server.method_3780() % 20 != 0) return;

            long currentTime = System.currentTimeMillis();

            for (class_3222 player : server.method_3760().method_14571()) {
                UUID uuid = player.method_5667();
                PlayerActivity activity = playerActivityMap.get(uuid);

                if (activity == null) {
                    activity = new PlayerActivity(player);
                    playerActivityMap.put(uuid, activity);
                    continue;
                }

                if (activity.hasMoved(player)) {
                    activity.updatePosition(player);
                    activity.lastActiveTime = currentTime;

                    if (activity.isAfk) {
                        activity.isAfk = false;
                        updatePlayerTab(server, player, false);
                    }
                } else {
                    if (!activity.isAfk && (currentTime - activity.lastActiveTime >= AFK_TIMEOUT_MS)) {
                        activity.isAfk = true;
                        updatePlayerTab(server, player, true);
                    }
                }
            }
        });
    }

    private static void updatePlayerTab(MinecraftServer server, class_3222 player, boolean isAfk) {
        class_269 scoreboard = server.method_3845();
        String playerName = player.method_5477().getString();

        class_268 oldTeam = scoreboard.method_1153(playerName);
        if (oldTeam != null) {
            scoreboard.method_1191(oldTeam);
        }

        class_268 team = scoreboard.method_1171(playerName);
        scoreboard.method_1172(playerName, team);

        class_2561 statusText = isAfk 
            ? class_2561.method_43470("AFK ").method_27695(class_124.field_1061, class_124.field_1067)
            : class_2561.method_43470("Online ").method_27695(class_124.field_1060, class_124.field_1067);

        team.method_1138(
            class_2561.method_43473()
                .method_10852(statusText)
                .method_10852(class_2561.method_43470("| ").method_27692(class_124.field_1067))
                .method_10852(class_2561.method_43470("CATWORLD.RP ").method_27694(s -> s.method_36139(0xFF7D00).method_10982(true)))
                .method_10852(class_2561.method_43470("| ").method_27692(class_124.field_1067))
                .method_10852(class_2561.method_43470("Desconosido").method_27692(class_124.field_1068))
        );

        team.method_1139(
            class_2561.method_43473()
                .method_10852(
                    class_2561.method_43470("\uE000\uE001")
                        .method_27694(style -> style
                            .method_27704(class_2960.method_60655("minecraft", "donate"))
                            .method_10982(true)
                            .method_10977(class_124.field_1065)
                        )
                )
        );

        team.method_1141(class_124.field_1063);
    }
}

