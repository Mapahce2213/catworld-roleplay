package catworld;

import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_3222;

public class tablist {

    public static void register() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.field_14140;
            class_269 scoreboard = server.method_3845();
            String playerName = player.method_5477().getString();

            class_268 team = scoreboard.method_1153(playerName);
            if (team == null) {
                team = scoreboard.method_1171(playerName);
            }

            scoreboard.method_1172(playerName, team);

            team.method_1138(
                class_2561.method_43473()
                    .method_10852(class_2561.method_43470("Online ").method_27695(class_124.field_1077, class_124.field_1067))
                    .method_10852(class_2561.method_43470("| ").method_27692(class_124.field_1067))
                    .method_10852(class_2561.method_43470("CATWORLD.RP ").method_27694(s -> s.method_36139(0xFF7D00).method_10982(true)))
                    .method_10852(class_2561.method_43470("| ").method_27692(class_124.field_1067))
            );
            
            team.method_1141(class_124.field_1068); 
        });
    }
}

