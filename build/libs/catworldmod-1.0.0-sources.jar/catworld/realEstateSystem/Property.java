package catworld.realEstateSystem;

import java.util.UUID;
import net.minecraft.class_2338;

/**
 * Represents a property in the real estate system.
 */
public class Property {

    private final String id;
    private final class_2338 signPosition;
    private final class_2338 minPosition;
    private final class_2338 maxPosition;
    private UUID ownerUUID;   // null if the property is unowned
    private final int price;

    /**
     * Constructs a new Property object with the specified parameters.
     * @param id .
     * @param signPosition .
     * @param minPosition .
     * @param maxPosition .
     * @param price .
     */
    public Property(String id, class_2338 signPosition, class_2338 minPosition, class_2338 maxPosition, int price) {
        this.id = id;
        this.signPosition = signPosition;
        this.minPosition = minPosition;
        this.maxPosition = maxPosition;
        this.price = price;
    }

    /**
     * Checks if the given coordinate is within the bounds of the property.
     * @param coordinate .
     * @return true if the coordinate is within the property bounds, false otherwise.
     */
    public boolean containsCoordinate(class_2338 coordinate) {
        return coordinate.method_10263() >= this.minPosition.method_10263() && coordinate.method_10263() <= this.maxPosition.method_10263() &&
               coordinate.method_10264() >= this.minPosition.method_10264() && coordinate.method_10264() <= this.maxPosition.method_10264() &&
               coordinate.method_10260() >= this.minPosition.method_10260() && coordinate.method_10260() <= this.maxPosition.method_10260();
    }

    public String getId() {
        return id;
    }

    public class_2338 getSignPosition() {
        return signPosition;
    }

    public class_2338 getMinPosition() {
        return minPosition;
    }

    public class_2338 getMaxPosition() {
        return maxPosition;
    }

    public UUID getOwnerUUID() {
        return ownerUUID;
    }

    public void setOwnerUUID(UUID ownerUUID) {
        this.ownerUUID = ownerUUID;
    }

    public int getPrice() {
        return price;
    }
}
