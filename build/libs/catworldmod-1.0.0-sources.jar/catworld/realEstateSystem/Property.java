package catworld.realEstateSystem;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.UUID;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonNull;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonPrimitive;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_2338;

public class Property {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path FILE_PATH = FabricLoader.getInstance()
            .getConfigDir()
            .resolve("catworld_properties.json");

    private final String id;
    private final class_2338 signPosition;
    private final class_2338 minPosition;
    private final class_2338 maxPosition;
    private UUID ownerUUID;
    private final int price;

  public Property(String id, class_2338 signPosition, class_2338 minPosition, class_2338 maxPosition, int price) {
    this.id = id;
    this.signPosition = signPosition;
    this.price = price;

    this.minPosition = new class_2338(
        Math.min(minPosition.method_10263(), maxPosition.method_10263()),
        Math.min(minPosition.method_10264(), maxPosition.method_10264()),
        Math.min(minPosition.method_10260(), maxPosition.method_10260())
    );

    this.maxPosition = new class_2338(
        Math.max(minPosition.method_10263(), maxPosition.method_10263()),
        Math.max(minPosition.method_10264(), maxPosition.method_10264()),
        Math.max(minPosition.method_10260(), maxPosition.method_10260())
    );
}


    public boolean containsCoordinate(class_2338 coordinate) {
        return coordinate.method_10263() >= this.minPosition.method_10263() && coordinate.method_10263() <= this.maxPosition.method_10263() &&
               coordinate.method_10264() >= this.minPosition.method_10264() && coordinate.method_10264() <= this.maxPosition.method_10264() &&
               coordinate.method_10260() >= this.minPosition.method_10260() && coordinate.method_10260() <= this.maxPosition.method_10260();
    }

    public String getId() {
        return id;
    }

    public class_2338 getSignPosition() {
        return signPosition;
    }

    public class_2338 getMinPosition() {
        return minPosition;
    }

    public class_2338 getMaxPosition() {
        return maxPosition;
    }

    public UUID getOwnerUUID() {
        return ownerUUID;
    }

    public void setOwnerUUID(UUID ownerUUID) {
        this.ownerUUID = ownerUUID;
    }

    public int getPrice() {
        return price;
    }

    // =====================  JSON =====================

    public static void loadAll(Map<class_2338, Property> propertiesBySign, Map<String, Property> propertiesById) {
        propertiesBySign.clear();
        propertiesById.clear();

        if (!Files.exists(FILE_PATH)) {
            System.out.println("[RealEstateSystem] " + FILE_PATH + " 404 error.");
            writeToDisk(propertiesById);
            return;
        }

        try (Reader reader = Files.newBufferedReader(FILE_PATH, StandardCharsets.UTF_8)) {
            JsonElement root = JsonParser.parseReader(reader);

            if (!root.isJsonArray()) {
                System.err.println("[RealEstateSystem] " + FILE_PATH + " broken.");
                return;
            }

            for (JsonElement element : root.getAsJsonArray()) {
                Property property = fromJson(element.getAsJsonObject());
                propertiesById.put(property.getId(), property);
                propertiesBySign.put(property.getSignPosition(), property);
            }

        } catch (IOException e) {
            System.err.println("[RealEstateSystem] 504 error " + FILE_PATH);
            e.printStackTrace();
        }
    }

    public static void save(Map<String, Property> propertiesById) {
        writeToDisk(propertiesById);
    }

    private static void writeToDisk(Map<String, Property> propertiesById) {
        JsonArray array = new JsonArray();
        for (Property property : propertiesById.values()) {
            array.add(property.toJson());
        }

        try {
            Files.createDirectories(FILE_PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE_PATH, StandardCharsets.UTF_8)) {
                GSON.toJson(array, writer);
            }
        } catch (IOException e) {
            System.err.println("[RealEstateSystem] Can't save " + FILE_PATH);
            e.printStackTrace();
        }
    }

    private static Property fromJson(JsonObject obj) {
        String id = obj.get("id").getAsString();
        class_2338 sign = readPos(obj.getAsJsonObject("tablichka"));
        class_2338 min = readPos(obj.getAsJsonObject("minPosition"));
        class_2338 max = readPos(obj.getAsJsonObject("maxPosition"));
        int price = obj.get("price").getAsInt();

        Property property = new Property(id, sign, min, max, price);

        if (obj.has("ownerUUID") && !obj.get("ownerUUID").isJsonNull()) {
            property.setOwnerUUID(UUID.fromString(obj.get("ownerUUID").getAsString()));
        }

        return property;
    }

    private JsonObject toJson() {
        JsonObject obj = new JsonObject();
        obj.addProperty("id", this.id);
        obj.add("tablichka", writePos(this.signPosition));
        obj.add("minPosition", writePos(this.minPosition));
        obj.add("maxPosition", writePos(this.maxPosition));
        obj.addProperty("price", this.price);
        obj.add("ownerUUID", this.ownerUUID != null ? new JsonPrimitive(this.ownerUUID.toString()) : JsonNull.INSTANCE);
        return obj;
    }

    private static class_2338 readPos(JsonObject obj) {
        return new class_2338(
            obj.get("x").getAsInt(),
            obj.get("y").getAsInt(),
            obj.get("z").getAsInt()
        );
    }

    private static JsonObject writePos(class_2338 pos) {
        JsonObject obj = new JsonObject();
        obj.addProperty("x", pos.method_10263());
        obj.addProperty("y", pos.method_10264());
        obj.addProperty("z", pos.method_10260());
        return obj;
    }
}
