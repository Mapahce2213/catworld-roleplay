package catworld.realEstateSystem;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_2561;

public class RealEstateManager {

    private static final Map<class_2338, Property> propertiesBySign = new HashMap<>();
    private static final Map<String, Property> propertiesById = new HashMap<>();

    /**
     * initializes the manager
     */
    public static void init() {

        registerProperty(new Property(
            "Apartment #001",
            new class_2338(149, 4, 154), 
            new class_2338(148, 3, 150),
            new class_2338(156, 6, 167), 
            10 
        ));

        registerProperty(new Property(
            "Apartment #002",
            new class_2338(142, 4, 154),
            new class_2338(132, 3, 150),
            new class_2338(140, 6, 167),
            12
        ));

        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.method_8608()) {
                return class_1269.field_5811;
            }

            class_2338 clickedPos = hitResult.method_17777();

            // chcks if hthe selected block is one of the registered signs
            if (propertiesBySign.containsKey(clickedPos)) {
                Property property = propertiesBySign.get(clickedPos);
                UUID playerUuid = player.method_5667();

                if (property.getOwnerUUID() == null) {

                    // buy logic
                    property.setOwnerUUID(playerUuid);
                    player.method_7353(class_2561.method_43470("¡Has comprado " + property.getId() + "!")
                            .method_27692(class_124.field_1060), false);
                } else if (property.getOwnerUUID().equals(playerUuid)) {
                    player.method_7353(class_2561.method_43470("Ya eres el dueño de esta propiedad.")
                            .method_27692(class_124.field_1054), false);
                } else {
                    player.method_7353(class_2561.method_43470("Esta propiedad ya tiene dueño.")
                            .method_27692(class_124.field_1061), false);
                }
                return class_1269.field_5812;
            }

            return class_1269.field_5811;
        });
    }

    /**
     * deletes an existing property
     * @param property .
     */
    public static void deleteProperty(Property property) {
        for(var prop: propertiesBySign.values()) {
            if(prop == property) {
                propertiesBySign.remove(property.getSignPosition());
                break;
            }

        propertiesBySign.remove(property.getSignPosition());
        propertiesById.remove(property.getId(), property);
        }
    }

    /**
     * registers a new property
     * @param property .
     */
    public static boolean registerProperty(Property property) {
        for(var prop: propertiesBySign.values()) {
            if(prop == property) {
                return false;
            }
        }
        propertiesBySign.put(property.getSignPosition(), property);
        propertiesById.put(property.getId(), property);
        return true;
    }

    public static boolean canBuildHere(UUID playerUuid, class_2338 pos) {
        for(var property: propertiesBySign.values()) {
            if(property.getSignPosition() == pos) {
                return true;
            }
        }
        return false;
    }
}
