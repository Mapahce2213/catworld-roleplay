package catworld.realEstateSystem;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

public class RealEstateManager {

    private static final Map<class_2338, Property> propertiesBySign = new HashMap<>();
    private static final Map<String, Property> propertiesById = new HashMap<>();

    public static void init(MinecraftServer server) {
        Property.loadAll(propertiesBySign, propertiesById);

        for (Property property : propertiesById.values()) {
            spawnSign(server, property);
        }

        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.method_8608()) {
                return class_1269.field_5811;
            }

            class_2338 clickedPos = hitResult.method_17777();

            if (propertiesBySign.containsKey(clickedPos)) {
                Property property = propertiesBySign.get(clickedPos);
                UUID playerUuid = player.method_5667();

                if (property.getOwnerUUID() == null) {
                    property.setOwnerUUID(playerUuid);
                    player.method_7353(class_2561.method_43470("¡Has comprado " + property.getId() + "!")
                            .method_27692(class_124.field_1060), false);
                    Property.save(propertiesById);
                    spawnSign(player.method_5682(), property);

                } else if (property.getOwnerUUID().equals(playerUuid)) {
                    player.method_7353(class_2561.method_43470("Ya eres el dueño de esta propiedad.")
                            .method_27692(class_124.field_1054), false);
                } else {
                    player.method_7353(class_2561.method_43470("Esta propiedad ya tiene dueño.")
                            .method_27692(class_124.field_1061), false);
                }
                return class_1269.field_5812;
            }

            return class_1269.field_5811;
        });
    }

private static void spawnSign(MinecraftServer server, Property property) {
    class_2338 pos = property.getSignPosition();
    int x = pos.method_10263();
    int y = pos.method_10264();
    int z = pos.method_10260();

    net.minecraft.class_3218 world = server.method_30002();
    String facing = "north";
    
    if (world != null) {
        if (world.method_8320(pos.method_10072()).method_26212(world, pos.method_10072())) {
            facing = "north";
        } else if (world.method_8320(pos.method_10095()).method_26212(world, pos.method_10095())) {
            facing = "south";
        } else if (world.method_8320(pos.method_10078()).method_26212(world, pos.method_10078())) {
            facing = "west";
        } else if (world.method_8320(pos.method_10067()).method_26212(world, pos.method_10067())) {
            facing = "east";
        }
    }

    run(server, String.format("setblock %d %d %d minecraft:oak_wall_sign[facing=%s]", x, y, z, facing));

    String line2 = "";
    String line2Color = "white";
    String line3 = "";
    String line3Color = "white";

    UUID owner = property.getOwnerUUID();
    
    if (owner != null) {
        class_3222 ownerPlayer = server.method_3760().method_14602(owner);
        
        if (ownerPlayer != null) {
            line2 = ownerPlayer.method_5477().getString();
            line2Color = "yellow";
        } else {
            var profileOpt = server.method_3793().method_14512(owner);
            
            if (profileOpt.isPresent()) {
                line2 = profileOpt.get().getName();
                line2Color = "yellow";
            } else {
                property.setOwnerUUID(null);
                owner = null; 
                Property.save(propertiesById);
            }
        }
    }
    
    if (owner == null) {
        line2 = property.getPrice() + "$";
        line2Color = "green";
        line3 = "selling";
        line3Color = "red";
    } else {
        if (line2.length() > 15) {
            line2 = line2.substring(0, 15);
        }
        line3 = ""; 
        line3Color = "white";
    }

    String dataCmd = String.format(
        "data merge block %d %d %d {front_text:{messages:['{\"text\":\"%s\",\"color\":\"aqua\",\"bold\":true}','{\"text\":\"%s\",\"color\":\"%s\"}','{\"text\":\"%s\",\"color\":\"%s\"}','{\"text\":\"\"}']}}",
        x, y, z, property.getId(), line2, line2Color, line3, line3Color
    );
    run(server, dataCmd);
}




    private static void run(MinecraftServer server, String command) {
        server.method_3734().method_44252(server.method_3739(), command);
    }

    public static void deleteProperty(Property property) {
        propertiesBySign.remove(property.getSignPosition());
        propertiesById.remove(property.getId(), property);
        Property.save(propertiesById);
    }

    public static boolean registerProperty(Property property) {
        if (propertiesById.containsKey(property.getId())) {
            return false;
        }
        propertiesBySign.put(property.getSignPosition(), property);
        propertiesById.put(property.getId(), property);
        Property.save(propertiesById);
        return true;
    }

    public static Collection<Property> getAllProperties() {
        return propertiesById.values();
    }

    public static boolean canBuildHere(UUID playerUuid, class_2338 pos) {
        for (Property property : propertiesBySign.values()) {
            if (property.getSignPosition().equals(pos)) {
                return true;
            }
        }
        return false;
    }
}

