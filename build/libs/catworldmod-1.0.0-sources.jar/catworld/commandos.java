package catworld;

import catworld.welcome;
import catworld.seguridad.Auth;
import catworld.seguridad.Joined;
import catworld.ciudadania.Ciudadanos;

import java.util.Map;
import java.util.HashMap;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_124;
import net.minecraft.class_1271;
import net.minecraft.class_1277;
import net.minecraft.class_1299;
import net.minecraft.class_1496;
import net.minecraft.class_1498;
import net.minecraft.class_1724;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_747;
import net.minecraft.class_9334;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;

public class commandos {

    private static final Map<String, Ciudadanos> ciudadanosByCedula = new HashMap<>();

static {
    Ciudadanos.loadAll(ciudadanosByCedula);
}


    public static void item() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            class_1799 stack = player.method_5998(hand);

            if (stack.method_7909() == class_1802.field_8687 &&
                stack.method_57824(class_9334.field_49631) != null &&
                stack.method_57824(class_9334.field_49631).getString().contains("Join to game")) {

                player.method_5682().method_3734().method_44252(
                    player.method_5671(), "game"
                );

                return class_1271.method_22427(stack);
            }
            
            
                  if (stack.method_7909() == class_1802.field_8251 &&
                stack.method_57824(class_9334.field_49631) != null &&
                stack.method_57824(class_9334.field_49631).getString().contains("Navigation")) {

                player.method_5682().method_3734().method_44252(
                    player.method_5671(), "namenu"
                );

                return class_1271.method_22427(stack);
            }
            

            return class_1271.method_22430(stack);
        });
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

     
      dispatcher.register(
    class_2170.method_9247("tellraw")
        .then(class_2170.method_9244("args", StringArgumentType.greedyString())
            .executes(context -> {
                context.getSource().method_9213(class_2561.method_43470("Command prohibed! NO PROMOTIONS"));
                return 0;
            })
        )
        .executes(context -> {
            context.getSource().method_9213(class_2561.method_43470("Command prohibed! NO PROMOTIONS"));
            return 0;
        })
); // No promotions of hosting

dispatcher.register(class_2170.method_9247("namenu").executes(context -> {
    class_3222 player = context.getSource().method_44023();
    if (player == null) return 0;

    class_1277 feagueInventory = new class_1277(2);

    class_1799 lightBlueGlass = new class_1799(class_1802.field_8196);
    lightBlueGlass.method_57379(class_9334.field_49631, class_2561.method_43470("§bJugar!"));

    class_1799 redGlass = new class_1799(class_1802.field_8879);
    redGlass.method_57379(class_9334.field_49631, class_2561.method_43470("§cDonacion"));

    feagueInventory.method_5447(0, lightBlueGlass);
    feagueInventory.method_5447(1, redGlass);

    class_1496 gingerHorse = new class_1498(class_1299.field_6139, player.method_37908());

    player.method_17355(new class_747(
        (syncId, playerInv, p) -> new class_1724(syncId, playerInv, feagueInventory, gingerHorse, 2),
        class_2561.method_43470("Menu of server")
    ));

    return 1;
}));




            
            
            // /spawn
            dispatcher.register(class_2170.method_9247("spawn").executes(context -> {
                class_3222 player = context.getSource().method_44023();
                if (player != null) {
                    class_2371<class_1799> currentInv = class_2371.method_10213(player.method_31548().field_7547.size(), class_1799.field_8037);
                    for (int i = 0; i < player.method_31548().field_7547.size(); i++) {
                        currentInv.set(i, player.method_31548().field_7547.get(i).method_7972());
                    }
                    welcome.saveWorldInventory(player.method_5667(), currentInv);

                    class_2371<class_1799> spawnInv = welcome.getSpawnInv();
                    player.method_31548().field_7547.clear();
                    for (int i = 0; i < spawnInv.size(); i++) {
                        player.method_31548().method_5447(i, spawnInv.get(i));
                    }

                    class_3218 world = player.method_51469();
                    class_2338 pos = new class_2338(-38, 47, 343);
                    player.method_14251(world, pos.method_10263(), pos.method_10264(), pos.method_10260(), player.method_36454(), player.method_36455());
                    player.method_7353(class_2561.method_43470("Has teleportado al spawn").method_27692(class_124.field_1065), false);
                }
                return 1;
            }));

// /game
dispatcher.register(class_2170.method_9247("game").executes(context -> {
    class_3222 player = context.getSource().method_44023();
    if (player == null) return 0;

    String playerUuid = player.method_5667().toString();
    Ciudadanos ciudadano = Ciudadanos.findByPassport(ciudadanosByCedula, playerUuid);

    if (ciudadano == null) {
        player.method_7353(
            class_2561.method_43470("Por favor escribe /register para registrar!").method_27695(class_124.field_1065, class_124.field_1067),
            false
        );
        return 1;
    }

    player.method_31548().field_7547.clear();
    class_2371<class_1799> worldInv = welcome.getWorldInventory(player.method_5667());
    for (int i = 0; i < worldInv.size(); i++) {
        player.method_31548().method_5447(i, worldInv.get(i));
    }

    class_3218 world = player.method_51469();
    class_2338 pos = new class_2338(40, 1, 68);
    player.method_14251(world, pos.method_10263(), pos.method_10264(), pos.method_10260(), player.method_36454(), player.method_36455());
    player.method_7353(class_2561.method_43470("Bien provecho!").method_27692(class_124.field_1065), false);

    return 1;
}));


// auth register <email> <contrasena> <repita>
// auth login <constrasena>

// /auth register <email> <contrasena> <repita>
// /auth login <contrasena>
dispatcher.register(
    class_2170.method_9247("auth")
        .then(class_2170.method_9247("register")
            .then(class_2170.method_9244("email", StringArgumentType.word())
                .then(class_2170.method_9244("contrasena", StringArgumentType.word())
                    .then(class_2170.method_9244("repita", StringArgumentType.word())
                        .executes(context -> {
                            class_3222 player = context.getSource().method_44023();
                            String email = StringArgumentType.getString(context, "email");
                            String password = StringArgumentType.getString(context, "contrasena");
                            String repeat = StringArgumentType.getString(context, "repita");

                            if (!password.equals(repeat)) {
                                player.method_7353(
                                    class_2561.method_43470("Las contraseñas no coinciden").method_27692(class_124.field_1061),
                                    false
                                );
                                return 0;
                            }

                            String uuid = player.method_5667().toString();
                            String ip = player.method_14209();
                            Map<String, Auth> authByUuid = Joined.getAuthByUuid();

                            boolean success = Auth.register(authByUuid, uuid, email, password, ip);

                            if (!success) {
                                player.method_7353(
                                    class_2561.method_43470("Ya estás registrado!").method_27692(class_124.field_1061),
                                    false
                                );
                                return 0;
                            }

                            Joined.markAuthenticated(player.method_5667());

                            player.method_7353(
                                class_2561.method_43470("Registro exitoso!").method_27692(class_124.field_1060),
                                false
                            );

                            return 1;
                        })
                    )
                )
            )
        )
        .then(class_2170.method_9247("login")
            .then(class_2170.method_9244("contrasena", StringArgumentType.word())
                .executes(context -> {
                    class_3222 player = context.getSource().method_44023();
                    String password = StringArgumentType.getString(context, "contrasena");
                    String uuid = player.method_5667().toString();
                    String ip = player.method_14209();
                    Map<String, Auth> authByUuid = Joined.getAuthByUuid();

                    boolean success = Auth.login(authByUuid, uuid, password, ip);

                    if (!success) {
                        player.method_7353(
                            class_2561.method_43470("Contraseña incorrecta o no estás registrado").method_27692(class_124.field_1061),
                            false
                        );
                        return 0;
                    }

                    Joined.markAuthenticated(player.method_5667());

                    player.method_7353(
                        class_2561.method_43470("Has iniciado sesión correctamente!").method_27692(class_124.field_1060),
                        false
                    );

                    return 1;
                })
            )
        )
);
            
            
            
 // register <nombre> <apedido> <edad> [Male\Female]
dispatcher.register(
    class_2170.method_9247("register")
        .then(class_2170.method_9244("nombre", StringArgumentType.word())
            .then(class_2170.method_9244("apedido", StringArgumentType.word())
                .then(class_2170.method_9244("edad", IntegerArgumentType.integer(0, 120))
                    .then(class_2170.method_9244("gender", StringArgumentType.word())
                        .suggests((context, builder) -> {
                            builder.suggest("Male");
                            builder.suggest("Female");
                            return builder.buildFuture();
                        })
                        .executes(context -> {
                            class_3222 player = context.getSource().method_44023();
                            String nombre = StringArgumentType.getString(context, "nombre");
                            String apedido = StringArgumentType.getString(context, "apedido");
                            int edad = IntegerArgumentType.getInteger(context, "edad");
                            String gender = StringArgumentType.getString(context, "gender");

                            if (!gender.equalsIgnoreCase("Male") && !gender.equalsIgnoreCase("Female")) {
                                player.method_7353(
                                    class_2561.method_43470("Gender debe ser Male o Female").method_27692(class_124.field_1061),
                                    false
                                );
                                return 0;
                            }

                            String playerUuid = player.method_5667().toString();

                            if (Ciudadanos.findByPassport(ciudadanosByCedula, playerUuid) != null) {
                                player.method_7353(
                                    class_2561.method_43470("Ya estás registrado!").method_27692(class_124.field_1061),
                                    false
                                );
                                return 0;
                            }

                            Ciudadanos ciudadano = new Ciudadanos();
                            ciudadano.setName(nombre);
                            ciudadano.setApedido(apedido);
                            ciudadano.setNickname(player.method_7334().getName());
                            ciudadano.setEdad(edad);
                            ciudadano.setGender(gender);
                            ciudadano.setPassport(playerUuid);
                            ciudadano.setCedula(playerUuid);

                            ciudadanosByCedula.put(ciudadano.getCedula(), ciudadano);
                            Ciudadanos.save(ciudadanosByCedula);

                            class_2561 message = class_2561.method_43470(
                                player.method_5477().getString() + " se registró como " + nombre + " " + apedido +
                                " (" + edad + " años, " + gender + ")"
                            ).method_27692(class_124.field_1054);

                            player.method_7353(message, false);

                            player.method_5682().method_3734().method_44252(
                                player.method_5671(), "game"
                            );

                            return 1;
                        })
                    )
                )
            )
        )
);

            // /rpme <action>
            dispatcher.register(
                class_2170.method_9247("rpme")
                    .then(class_2170.method_9244("action", StringArgumentType.greedyString())
                        .executes(context -> {
                            class_3222 player = context.getSource().method_44023();
                            String action = StringArgumentType.getString(context, "action");

                            class_2561 message = class_2561.method_43470(player.method_5477().getString() + " " + action)
                                .method_27692(class_124.field_1076);

                            for (class_3222 target : player.method_5682().method_3760().method_14571()) {
                                double distance = player.method_24515().method_19455(target.method_24515());
                                if (distance <= 20) {
                                    target.method_7353(message, false);
                                }
                            }
                            return 1;
                        })
                    )
            );

            // /rpdo <action>
            dispatcher.register(
                class_2170.method_9247("rpdo")
                    .then(class_2170.method_9244("action", StringArgumentType.greedyString())
                        .executes(context -> {
                            class_3222 player = context.getSource().method_44023();
                            String action = StringArgumentType.getString(context, "action");

                            class_2561 message = class_2561.method_43470(action)
                              .method_27692(class_124.field_1054);

                            for (class_3222 target : player.method_5682().method_3760().method_14571()) {
                                double distance = player.method_24515().method_19455(target.method_24515());
                                if (distance <= 20) {
                                    target.method_7353(message, false);
                                }
                            }
                            return 1;
                        })
                    )
            );
        });
    }
}
