package catworld;
import catworld.welcome;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_124;
import net.minecraft.class_1271;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2170;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_9334;
import com.mojang.brigadier.arguments.StringArgumentType;

public class commandos {

    public static void item() {
        UseItemCallback.EVENT.register((player, world, hand) -> {
            class_1799 stack = player.method_5998(hand);

            if (stack.method_7909() == class_1802.field_8687 &&
                stack.method_57824(class_9334.field_49631) != null &&
                stack.method_57824(class_9334.field_49631).getString().contains("Join to game")) {

                player.method_5682().method_3734().method_44252(
                    player.method_5671(), "game"
                );

                return class_1271.method_22427(stack);
            }

            return class_1271.method_22430(stack);
        });
    }

    public static void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {

            dispatcher.register(
                class_2170.method_9247("tellraw")
                    .requires(source -> false) // никто и никогда не сможет её выполнить
            );

            // /spawn
            dispatcher.register(class_2170.method_9247("spawn").executes(context -> {
                class_3222 player = context.getSource().method_44023();
                if (player != null) {
                    class_2371<class_1799> currentInv = class_2371.method_10213(player.method_31548().field_7547.size(), class_1799.field_8037);
                    for (int i = 0; i < player.method_31548().field_7547.size(); i++) {
                        currentInv.set(i, player.method_31548().field_7547.get(i).method_7972());
                    }
                    welcome.saveWorldInventory(player.method_5667(), currentInv);

                    class_2371<class_1799> spawnInv = welcome.getSpawnInv();
                    player.method_31548().field_7547.clear();
                    for (int i = 0; i < spawnInv.size(); i++) {
                        player.method_31548().method_5447(i, spawnInv.get(i));
                    }

                    class_3218 world = player.method_51469();
                    class_2338 pos = new class_2338(-38, 47, 343);
                    player.method_14251(world, pos.method_10263(), pos.method_10264(), pos.method_10260(), player.method_36454(), player.method_36455());
                    player.method_7353(class_2561.method_43470("Has teleportado al spawn").method_27692(class_124.field_1065), false);
                }
                return 1;
            }));

            // /game
            dispatcher.register(class_2170.method_9247("game").executes(context -> {
                class_3222 player = context.getSource().method_44023();
                if (player != null) {
                    player.method_31548().field_7547.clear();
                    class_2371<class_1799> worldInv = welcome.getWorldInventory(player.method_5667());
                    for (int i = 0; i < worldInv.size(); i++) {
                        player.method_31548().method_5447(i, worldInv.get(i));
                    }

                    class_3218 world = player.method_51469();
                    class_2338 pos = new class_2338(40, 1, 68);
                    player.method_14251(world, pos.method_10263(), pos.method_10264(), pos.method_10260(), player.method_36454(), player.method_36455());
                    player.method_7353(class_2561.method_43470("Bien provecho!").method_27692(class_124.field_1065), false);
                }
                return 1;
            }));

            // /rpme <action>
            dispatcher.register(
                class_2170.method_9247("rpme")
                    .then(class_2170.method_9244("action", StringArgumentType.greedyString())
                        .executes(context -> {
                            class_3222 player = context.getSource().method_44023();
                            String action = StringArgumentType.getString(context, "action");

                            class_2561 message = class_2561.method_43470(player.method_5477().getString() + " " + action)
                                .method_27692(class_124.field_1076);

                            for (class_3222 target : player.method_5682().method_3760().method_14571()) {
                                double distance = player.method_24515().method_19455(target.method_24515());
                                if (distance <= 20) {
                                    target.method_7353(message, false);
                                }
                            }
                            return 1;
                        })
                    )
            );

            // /rpdo <action>
            dispatcher.register(
                class_2170.method_9247("rpdo")
                    .then(class_2170.method_9244("action", StringArgumentType.greedyString())
                        .executes(context -> {
                            class_3222 player = context.getSource().method_44023();
                            String action = StringArgumentType.getString(context, "action");

                            class_2561 message = class_2561.method_43470(action)
                              .method_27692(class_124.field_1054);

                            for (class_3222 target : player.method_5682().method_3760().method_14571()) {
                                double distance = player.method_24515().method_19455(target.method_24515());
                                if (distance <= 20) {
                                    target.method_7353(message, false);
                                }
                            }
                            return 1;
                        })
                    )
            );
        });
    }
}
