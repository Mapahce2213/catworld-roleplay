package catworld;
import catworld.commandos;
import catworld.tablist;
import catworld.realEstateSystem.RealEstateManager;
import catworld.boardes;
import catworld.blocker;


import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_9334;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import java.util.Map;
import java.util.HashMap;
import java.util.UUID;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import com.mojang.brigadier.arguments.StringArgumentType;



public class welcome implements ModInitializer {

private static final Map<UUID, class_2371<class_1799>> spawnInventories = new HashMap<>();
private static final Map<UUID, class_2371<class_1799>> worldInventories = new HashMap<>();



	@Override
    public void onInitialize() {
        System.out.println("Catworld модификация была активированна | El modo has activado");
        
ServerLifecycleEvents.SERVER_STARTED.register(server -> {
            RealEstateManager.init(server);
        });

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.field_14140;




    class_2371<class_1799> currentInv = class_2371.method_10213(player.method_31548().field_7547.size(), class_1799.field_8037);
    for (int i = 0; i < player.method_31548().field_7547.size(); i++) {
        currentInv.set(i, player.method_31548().field_7547.get(i).method_7972());
    }
    saveWorldInventory(player.method_5667(), currentInv);

    class_2371<class_1799> spawnInv = getSpawnInv();

    player.method_31548().field_7547.clear();
    for (int i = 0; i < spawnInv.size(); i++) {
        player.method_31548().method_5447(i, spawnInv.get(i));
    
    }
    
    
    
        class_3218 world = player.method_51469();
    class_2338 pos = new class_2338(-38, 47, 343);
    player.method_14251(world, pos.method_10263(), pos.method_10264(), pos.method_10260(), player.method_36454(), player.method_36455());
    
    
if (player.method_14248().method_15025(net.minecraft.class_3468.field_15419.method_14956(net.minecraft.class_3468.field_15417)) > 0) {
    server.method_3760().method_43514(class_2561.method_43470("[").method_10852(class_2561.method_43470("+").method_27692(class_124.field_1060)).method_10852(class_2561.method_43470("] El jugador has unido")), false);
} else {
    server.method_3760().method_43514(class_2561.method_43470("[").method_10852(class_2561.method_43470("+").method_27692(class_124.field_1060)).method_10852(class_2561.method_43470("] Otro nuevo mas")), false);
}

            player.method_7353(class_2561.method_43470("§l§6================CatWorld RP================"), false);
            player.method_7353(class_2561.method_43470("§aBienvenido! Felicitamos que eligiste a nosotros!"), false);
            player.method_7353(class_2561.method_43470("§e1. Descarge los modos"), false);
            player.method_7353(class_2561.method_43470("§e2. Prende resourcepacks"), false);
            player.method_7353(class_2561.method_43470("§e2. Usa commandos /me /do para RP!"), false);
            player.method_7353(class_2561.method_43470("§e3. Tenemos grupo en Facebook"), false);
            player.method_7353(class_2561.method_43470("§l§6================Buen provecho!================"), false);



        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            server.method_3760().method_43514(class_2561.method_43470(""), false);
        });

blocker.blockblock();
blocker.changeblock();

commandos.register();
boardes.reglas();
commandos.item();

tablist.register();

 ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, params) -> {

            class_2561 localMessage = class_2561.method_43470(
                "[" + sender.method_5477().getString() + "] [ADMIN] " + message.method_46291().getString()
            );

            for (class_3222 target : sender.method_5682().method_3760().method_14571()) {
                double distance = sender.method_24515().method_19455(target.method_24515());
                if (distance <= 20) {
                    target.method_7353(localMessage, false);
                }
            }

            return false;
        });




    
        ServerLifecycleEvents.SERVER_STOPPED.register(server -> {
            System.out.println("Мод был остановлен вручную | El modo has parado manual");
        });
    }
    
public static class_2371<class_1799> getSpawnInv() {
    class_2371<class_1799> inv = class_2371.method_10213(36, class_1799.field_8037);

    class_1799 emerald = new class_1799(class_1802.field_8687);
    emerald.method_57379(class_9334.field_49631, class_2561.method_43470("Join to game").method_27692(class_124.field_1065));
    inv.set(0, emerald);

    class_1799 compass = new class_1799(class_1802.field_8251);
    compass.method_57379(class_9334.field_49631, class_2561.method_43470("Navigation").method_27692(class_124.field_1060));
    inv.set(1, compass);

    return inv;
}


    public static void saveWorldInventory(UUID uuid, class_2371<class_1799> inv) {
        worldInventories.put(uuid, inv);
    }

    public static class_2371<class_1799> getWorldInventory(UUID uuid) {
        return worldInventories.getOrDefault(uuid, class_2371.method_10213(36, class_1799.field_8037));
    }


    
    
    
}
