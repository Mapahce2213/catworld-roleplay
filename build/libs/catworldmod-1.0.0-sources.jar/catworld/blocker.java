package catworld;

import catworld.realEstateSystem.Property;
import catworld.realEstateSystem.RealEstateManager;

import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import java.util.UUID;

public class blocker {

    public static void blockblock() {
        AttackBlockCallback.EVENT.register((player, world, hand, pos, direction) -> {
            if (world.method_8608()) return class_1269.field_5811;

            if (hasPermission(player.method_5667(), pos)) {
                return class_1269.field_5811;
            }

            player.method_7353(class_2561.method_43470("§cAqui no puede destruir blockes >:("), false);
            return class_1269.field_5814;
        });
    }

    public static void changeblock() {
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (world.method_8608()) return class_1269.field_5811;

            class_2338 pos = hitResult.method_17777();

            if (hasPermission(player.method_5667(), pos)) {
                return class_1269.field_5811;
            }

            class_2680 state = world.method_8320(pos);

            if (state.method_26164(class_3481.field_15487)) {
                player.method_7353(class_2561.method_43470("§cAqui no puede interactuar >:("), false);
                return class_1269.field_5814;
            }

            if (state.method_26204() instanceof net.minecraft.class_2281 || 
                state.method_27852(net.minecraft.class_2246.field_10443) || 
                state.method_26164(class_3481.field_21490)) {
                player.method_7353(class_2561.method_43470("§cAqui no puede abrir cofres >:("), false);
                return class_1269.field_5814;
            }

            if (!player.method_5998(hand).method_7960() && player.method_5998(hand).method_7909() instanceof net.minecraft.class_1747) {
                player.method_7353(class_2561.method_43470("§cAqui no puede colocar bloques >:("), false);
                return class_1269.field_5814;
            }

            return class_1269.field_5811;
        });
    }

    private static boolean hasPermission(UUID playerUuid, class_2338 pos) {
        for (Property property : RealEstateManager.getAllProperties()) {
            if (property.containsCoordinate(pos)) {
                UUID owner = property.getOwnerUUID();
                
                if (owner == null || !owner.equals(playerUuid)) {
                    return false;
                }
            }
        }
        return true; 
    }
}

