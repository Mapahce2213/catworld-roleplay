package catworld.seguridad;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_124;
import net.minecraft.class_1271;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

public class Joined {

    private static final Map<String, Auth> authByUuid = new HashMap<>();

    private static final Set<UUID> unauthenticated = new HashSet<>();

    private static final Map<UUID, class_243> frozenPosition = new HashMap<>();

    public static void init(MinecraftServer server) {
        Auth.loadAll(authByUuid);
        registerEvents();
    }

    private static void registerEvents() {

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.method_32311();
            String uuid = player.method_5667().toString();

            if (!authByUuid.containsKey(uuid)) {
                unauthenticated.add(player.method_5667());
                frozenPosition.put(player.method_5667(), player.method_19538());

                player.method_7353(
                    class_2561.method_43470("Por favor escribe /auth register <email> <contrasena> <repita contrasena>").method_27692(class_124.field_1061),
                    false
                );
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (UUID uuid : unauthenticated) {
                class_3222 player = server.method_3760().method_14602(uuid);
                if (player == null) continue;

                class_243 frozen = frozenPosition.get(uuid);
                if (frozen != null) {
                    player.method_14251(player.method_51469(), frozen.field_1352, frozen.field_1351, frozen.field_1350, player.method_36454(), player.method_36455());
                }
            }
        });


        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (unauthenticated.contains(player.method_5667())) {
                return class_1271.method_22431(player.method_5998(hand));
            }
            return class_1271.method_22430(player.method_5998(hand));
        });
    }

    public static void markAuthenticated(UUID uuid) {
        unauthenticated.remove(uuid);
        frozenPosition.remove(uuid);
    }

    public static Map<String, Auth> getAuthByUuid() {
        return authByUuid;
    }
}
