package catworld.seguridad;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.minecraft.class_1294;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import catworld.seguridad.Joined;

public class Anticheat {


    private static final double MAX_HORIZONTAL_SPEED_PER_TICK = 0.6;

    private static final double MAX_VERTICAL_RISE_PER_TICK = 0.5;

    private static final int FLY_SUSPICION_TICKS = 10;

    private static final long MIN_BREAK_INTERVAL_MS = 50;

    private static final int MAX_PING_MS = 1000;


    private static final Map<UUID, class_243> lastPosition = new HashMap<>();
    private static final Map<UUID, Integer> flySuspicionCounter = new HashMap<>();
    private static final Map<UUID, Long> lastBreakTime = new HashMap<>();

    public static void init(MinecraftServer server) {
        registerEvents();
    }

    private static void registerEvents() {

        ServerTickEvents.END_SERVER_TICK.register(Anticheat::checkAllPlayers);

        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!(player instanceof class_3222 serverPlayer)) {
                return;
            }
            checkBreakSpeed(serverPlayer);
        });
    }

    private static void checkAllPlayers(MinecraftServer server) {
        for (class_3222 player : server.method_3760().method_14571()) {
            checkFlight(player);
            checkSpeed(player);
            checkPing(player);
        }
    }

    private static void checkFlight(class_3222 player) {
        UUID uuid = player.method_5667();
        class_243 current = player.method_19538();
        class_243 previous = lastPosition.getOrDefault(uuid, current);
        lastPosition.put(uuid, current);

        double verticalDelta = current.field_1351 - previous.field_1351;

        boolean hasLegitimateFlightReason =
            player.method_31549().field_7479 
                || player.method_6128() 
                || player.method_5765() 
                || player.method_5799()
                || player.method_5771()
                || player.method_6101()  
                || player.method_6059(class_1294.field_5902)
                || player.method_7325();

        if (hasLegitimateFlightReason) {
            flySuspicionCounter.put(uuid, 0);
            return;
        }

        if (verticalDelta > MAX_VERTICAL_RISE_PER_TICK && !player.method_24828()) {
            int count = flySuspicionCounter.getOrDefault(uuid, 0) + 1;
            flySuspicionCounter.put(uuid, count);

            if (count >= FLY_SUSPICION_TICKS) {
                banPlayer(player, "Vuelo no permitido detectado");
                flySuspicionCounter.put(uuid, 0);
            }
        } else {
            flySuspicionCounter.put(uuid, 0);
        }
    }

    private static void checkSpeed(class_3222 player) {
        class_243 current = player.method_19538();
        class_243 previous = lastPosition.getOrDefault(player.method_5667(), current);

        double horizontalDistance = Math.sqrt(
            Math.pow(current.field_1352 - previous.field_1352, 2) + Math.pow(current.field_1350 - previous.field_1350, 2)
        );

        boolean hasLegitimateSpeedReason =
            player.method_5765()
                || player.method_6059(class_1294.field_5904)
                || player.method_6128()
                || player.method_31549().field_7479;

        if (hasLegitimateSpeedReason) {
            return;
        }

        if (horizontalDistance > MAX_HORIZONTAL_SPEED_PER_TICK) {
            banPlayer(player, "Velocidad de movimiento no permitida detectada");
        }
    }

    private static void checkBreakSpeed(class_3222 player) {
        UUID uuid = player.method_5667();
        long now = System.currentTimeMillis();
        Long last = lastBreakTime.get(uuid);
        lastBreakTime.put(uuid, now);

        if (last == null) {
            return;
        }

        long interval = now - last;
        if (interval < MIN_BREAK_INTERVAL_MS) {
            kickPlayer(player, "Velocidad de minado no permitida detectada");
        }
    }

    private static void checkPing(class_3222 player) {
        int ping = player.field_13987.method_52405();
        if (ping > MAX_PING_MS) {
            kickPlayer(player, "Ping demasiado alto (" + ping + "ms)");
        }
    }



  private static void banPlayer(class_3222 player, String reason) {
    player.field_13987.method_52396(class_2561.method_43470("Baneado: " + reason));

    String uuid = player.method_5667().toString();
    Map<String, Auth> authByUuid = Joined.getAuthByUuid();

    Auth auth = Auth.findByUuid(authByUuid, uuid);
    if (auth != null) {
        auth.setBanned(true);
        Auth.save(authByUuid);
    }
}

    private static void kickPlayer(class_3222 player, String reason) {
        player.field_13987.method_52396(class_2561.method_43470("Expulsado: " + reason));
    }
}
