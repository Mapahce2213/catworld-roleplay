package catworld;

import java.util.Optional;
import java.util.UUID;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_2736;
import net.minecraft.class_274;
import net.minecraft.class_2751;
import net.minecraft.class_2757;
import net.minecraft.class_3222;
import net.minecraft.class_8646;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import catworld.ciudadania.Ciudadanos;
import catworld.seguridad.Auth;
import catworld.seguridad.Joined;

public class Sidebar {

    private static final String OBJECTIVE_NAME = "catworld_sidebar";
    private static final int UPDATE_INTERVAL_TICKS = 100;

    public static final Map<String, Ciudadanos> ciudadanosByCedula = new ConcurrentHashMap<>();

    private static final Map<UUID, Ciudadanos> ciudadanosCache = new ConcurrentHashMap<>();
    private static final Map<UUID, String> donationCache = new ConcurrentHashMap<>();
    
    private static class SidebarState {
        String lastNombre = "";
        String lastApedido = "";
        String lastEdad = "";
        String lastDonacion = "";
        String lastFraccion = "";
        boolean isInitialized = false;
    }

    private static final Map<UUID, SidebarState> playerStates = new ConcurrentHashMap<>();

    public static void register() {

        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.field_14140;
            if (player == null) return;
            
            UUID uuid = player.method_5667();
            String nickname = player.method_5477().getString();
            playerStates.put(uuid, new SidebarState());

            Thread.startVirtualThread(() -> {
                Ciudadanos ciudadano = Ciudadanos.findByNickname(ciudadanosByCedula, nickname);
                if (ciudadano != null) {
                    ciudadanosCache.put(uuid, ciudadano);
                }

                String status = "No hay";
                try {
                    Auth auth = Auth.findByUuid(Joined.getAuthByUuid(), uuid.toString());
                    if (auth != null && auth.getStatus() != null) {
                        status = auth.getStatus();
                    }
                } catch (Exception e) {
                    status = "Error404";
                }
                donationCache.put(uuid, status);
                
                server.execute(() -> update(player));
            });
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            if (handler.field_14140 != null) {
                UUID uuid = handler.field_14140.method_5667();
                hide(handler.field_14140);
                playerStates.remove(uuid);
                donationCache.remove(uuid);
                ciudadanosCache.remove(uuid);
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.method_3780() % UPDATE_INTERVAL_TICKS != 0) return;

            for (class_3222 player : server.method_3760().method_14571()) {
                if (player != null) {
                    update(player);
                }
            }
        });
    }

    public static void reloadPlayerCache(class_3222 player) {
        if (player == null) return;
        UUID uuid = player.method_5667();
        String nickname = player.method_5477().getString();

        Ciudadanos ciudadano = Ciudadanos.findByNickname(ciudadanosByCedula, nickname);
        if (ciudadano != null) {
            ciudadanosCache.put(uuid, ciudadano);
        } else {
            ciudadanosCache.remove(uuid);
        }
        update(player);
    }

    public static void update(class_3222 player) {
        if (player == null) return;

        Ciudadanos ciudadano = ciudadanosCache.get(player.method_5667());
        String donacionStatus = donationCache.getOrDefault(player.method_5667(), "No hay");

        show(player, ciudadano, donacionStatus);
    }

    public static void show(class_3222 player, Ciudadanos ciudadano, String donacionStatus) {
        UUID uuid = player.method_5667();
        SidebarState state = playerStates.computeIfAbsent(uuid, k -> new SidebarState());

        String nombre = (ciudadano != null && ciudadano.getName() != null) ? ciudadano.getName() : "???";
        String apedido = (ciudadano != null && ciudadano.getApedido() != null) ? ciudadano.getApedido() : "???";
        String edad = (ciudadano != null) ? String.valueOf(ciudadano.getEdad()) : "???";
        String fraccion = (ciudadano != null && ciudadano.getTrabajo() != null && ciudadano.getTrabajo().getFraccion() != null)
            ? ciudadano.getTrabajo().getFraccion()
            : "No hay";

        class_266 objective = new class_266(
            null, OBJECTIVE_NAME, class_274.field_1468,
            class_2561.method_43470("Catworld RP").method_27695(class_124.field_1065, class_124.field_1067),
            class_274.class_275.field_1472, false, null
        );

        if (!state.isInitialized) {
            player.field_13987.method_14364(new class_2751(objective, 0));
            player.field_13987.method_14364(new class_2736(class_8646.field_45157, objective));
            
            sendLine(player, objective, "line8", 8, "§7-----------------------");
            sendLine(player, objective, "line7", 7, "§eNombre: §f" + nombre);
            sendLine(player, objective, "line6", 6, "§eApedido: §f" + apedido);
            sendLine(player, objective, "line5", 5, "§eEdad: §f" + edad);
            sendLine(player, objective, "line4", 4, "§eDonacion: §f" + donacionStatus);
            sendLine(player, objective, "line3", 3, "§eFraccion: §f" + fraccion);
            sendLine(player, objective, "line2", 2, "§7  -------------------");
            sendLine(player, objective, "line1", 1, "§6[CatWorld RP]");

            state.lastNombre = nombre;
            state.lastApedido = apedido;
            state.lastEdad = edad;
            state.lastDonacion = donacionStatus;
            state.lastFraccion = fraccion;
            state.isInitialized = true;
            return;
        }

        if (!state.lastNombre.equals(nombre)) {
            sendLine(player, objective, "line7", 7, "§eNombre: §f" + nombre);
            state.lastNombre = nombre;
        }
        if (!state.lastApedido.equals(apedido)) {
            sendLine(player, objective, "line6", 6, "§eApedido: §f" + apedido);
            state.lastApedido = apedido;
        }
        if (!state.lastEdad.equals(edad)) {
            sendLine(player, objective, "line5", 5, "§eEdad: §f" + edad);
            state.lastEdad = edad;
        }
        if (!state.lastDonacion.equals(donacionStatus)) {
            sendLine(player, objective, "line4", 4, "§eDonacion: §f" + donacionStatus);
            state.lastDonacion = donacionStatus;
        }
        if (!state.lastFraccion.equals(fraccion)) {
            sendLine(player, objective, "line3", 3, "§eFraccion: §f" + fraccion);
            state.lastFraccion = fraccion;
        }
    }

    private static void sendLine(class_3222 player, class_266 objective,
                                  String owner, int score, String text) {
        player.field_13987.method_14364(
            new class_2757(
                owner,
                objective.method_1113(),
                score,
                Optional.of(class_2561.method_43470(text)),
                Optional.empty()
            )
        );
    }

    public static void hide(class_3222 player) {
        class_266 objective = new class_266(
            null, OBJECTIVE_NAME, class_274.field_1468,
            class_2561.method_43470(""), class_274.class_275.field_1472, false, null
        );

        player.field_13987.method_14364(
            new class_2751(objective, 1)
        );
    }
}

