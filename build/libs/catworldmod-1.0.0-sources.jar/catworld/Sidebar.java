package catworld;

import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.UUID;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_2736;
import net.minecraft.class_274;
import net.minecraft.class_2751;
import net.minecraft.class_2757;
import net.minecraft.class_3222;
import net.minecraft.class_8646;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

import catworld.ciudadania.Ciudadanos;
import catworld.seguridad.Auth;
import catworld.seguridad.Joined;

public class Sidebar {

    private static final String OBJECTIVE_NAME = "catworld_sidebar";
    private static int tickCounter = 0;

    private static final Set<UUID> initialized = ConcurrentHashMap.newKeySet();

    public static void register() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.field_14140;
            initialized.remove(player.method_5667());
            update(player);
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            if (handler.field_14140 != null) {
                hide(handler.field_14140);
                initialized.remove(handler.field_14140.method_5667());
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            tickCounter++;
            if (tickCounter >= 10) {
                tickCounter = 0;
                for (class_3222 player : server.method_3760().method_14571()) {
                    if (player != null) {
                        update(player);
                    }
                }
            }
        });
    }

    public static void update(class_3222 player) {
        if (player == null) return;

        Ciudadanos ciudadano = null;

        String donacionStatus = "No hay";
        try {
            Auth auth = Auth.findByUuid(Joined.getAuthByUuid(), player.method_5667().toString());
            if (auth != null && auth.getStatus() != null) {
                donacionStatus = auth.getStatus();
            }
        } catch (Exception e) {
            donacionStatus = "Error404";
        }

        show(player, ciudadano, donacionStatus);
    }

    public static void show(class_3222 player, Ciudadanos ciudadano, String donacionStatus) {
        class_266 objective = new class_266(
            null,
            OBJECTIVE_NAME,
            class_274.field_1468,
            class_2561.method_43470("Catworld RP").method_27695(class_124.field_1065, class_124.field_1067),
            class_274.class_275.field_1472,
            false,
            null
        );

        UUID uuid = player.method_5667();
        boolean firstTime = initialized.add(uuid);

        if (firstTime) {
            player.field_13987.method_14364(
                new class_2751(objective, 0)
            );

            player.field_13987.method_14364(
                new class_2736(class_8646.field_45157, objective)
            );
        } else {
            player.field_13987.method_14364(
                new class_2751(objective, 2)
            );
        }

        String nombre = (ciudadano != null && ciudadano.getName() != null) ? ciudadano.getName() : "???";
        String apedido = (ciudadano != null && ciudadano.getApedido() != null) ? ciudadano.getApedido() : "???";
        String edad = (ciudadano != null) ? String.valueOf(ciudadano.getEdad()) : "???";
        String fraccion = (ciudadano != null && ciudadano.getTrabajo() != null && ciudadano.getTrabajo().getFraccion() != null)
            ? ciudadano.getTrabajo().getFraccion()
            : "No hay";

        sendLine(player, objective, "line8", 8, "§7-----------------------");
        sendLine(player, objective, "line6", 6, "§eNombre: §f" + nombre);
        sendLine(player, objective, "line5", 5, "§eApedido: §f" + apedido);
        sendLine(player, objective, "line4", 4, "§eEdad: §f" + edad);
        sendLine(player, objective, "line3", 3, "§eDonacion: §f" + donacionStatus);
        sendLine(player, objective, "line2", 2, "§eFraccion: §f" + fraccion);
        sendLine(player, objective, "line1", 1, "§7  -------------------");
        sendLine(player, objective, "line0", 0, "§6[CatWorld RP]");
    }

    private static void sendLine(class_3222 player, class_266 objective,
                                  String owner, int score, String text) {
        player.field_13987.method_14364(
            new class_2757(
                owner,
                objective.method_1113(),
                score,
                Optional.of(class_2561.method_43470(text)),
                Optional.empty()
            )
        );
    }

    public static void hide(class_3222 player) {
        class_266 objective = new class_266(
            null, OBJECTIVE_NAME, class_274.field_1468,
            class_2561.method_43470(""), class_274.class_275.field_1472, false, null
        );

        player.field_13987.method_14364(
            new class_2751(objective, 1)
        );
    }
}
